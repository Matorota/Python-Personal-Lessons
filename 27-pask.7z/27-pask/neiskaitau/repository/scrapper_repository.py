

def hello():
    message = "Hello world!!"
    return {"message": message}
