from question_bank import QuestionBank
from question_bank import Quesetion

question_bank = QuestionBank()
single_q = Quesetion()

is_on = True

while is_on:
    print("")

    # options = question_bank.get_category()
    # choice = input(f"?({options})")


