import tkinter as tk

window = tk.Tk()

my_checkbutton = tk.Checkbutton(text="are you gay?")
my_checkbutton.pack()
window.mainloop()
