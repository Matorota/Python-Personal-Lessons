import tkinter as tk
parent = tk.Tk()
parent.title('Title - button')
my_button = tk.Button(parent, text='Quit', height=1, width=35, command=parent.destroy)
my_button.pack() 
parent.mainloop()