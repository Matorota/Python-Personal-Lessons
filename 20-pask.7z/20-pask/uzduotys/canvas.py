from tkinter import *

canvas = Canvas()
canvas.create_line(15, 50, 50, 60)
canvas.pack()

canvas.mainloop()
